export const Questions = [
    {
        prompt: "What is 2+3?",
        optionA: 10,
        optionB: 3,
        optionC: 5,
        optionD: 20,
        answer: "C"
    },
    {
        prompt: "What is 1+1?",
        optionA: 10,
        optionB: 2,
        optionC: 5,
        optionD: 20,
        answer: "B"
    },
    {
        prompt: "What is 2*10?",
        optionA: 20,
        optionB: 3,
        optionC: 5,
        optionD: 6,
        answer: "A"
    },
    {
        prompt: "What is 6/3?",
        optionA: 2,
        optionB: 3,
        optionC: 5,
        optionD: 20,
        answer: "A"
    },
    {
        prompt: "What is 20+5?",
        optionA: 10,
        optionB: 3,
        optionC: 6,
        optionD: 25,
        answer: "D"
    }
] 